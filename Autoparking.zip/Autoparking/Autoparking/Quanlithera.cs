﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autoparking
{
    public partial class Quanlithera : Form
    {
        public Quanlithera()
        {
            InitializeComponent();
        }

        private void Quanlithera_Load(object sender, EventArgs e)
        {
            int i;
            //Bách ngây thơ
        }
    }
}
